xelatex seuthesix.dtx 
bibtex seuthesix  
makeindex seuthesix.nlo -s nomencl.ist -o seuthesix.nls 
xelatex seuthesix.dtx  
xelatex seuthesix.dtx
